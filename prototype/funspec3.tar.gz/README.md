Description
===========

In this work we aim at providing an effective support for reasoning about imperative programs with data structures and aliasing, by extending the expressiveness of more familiar type-based verification towards more informative logical reasoning, without compromising soundness and completeness.

Currently is hard to reason about global and shape properties of data structures. Existing tools require too much effort, a lot of experience from the user and rely on mechanisms that don't scale.

We develop an assertion language that is closer to a programming language, that we call, functional assertion language, which is easier to use for programmers, and amenable to automatic verification.

This prototype checks "logical" relations between functional assertions, that is, if an assertion is equivalent to, or implies other assertion.

Downloads
=========

[Packaged Version](http://ctp.di.fct.unl.pt/~tsantos/tools/funspec.tar.gz)

You can try our tool online [here](http://ctp.di.fct.unl.pt/~tsantos/funspec/play)

Installation
============

1. Download the packaged version above

2. Unpack the tar.gz file

3. Execute the funspec script following the instructions below

Usage
=====

```
FunSpec [version 0.0.2]. (C) Copyright 2016
Usage: sh funspec [OPTION]...

Options:

  -a, --api                Force smt api usage

  -d, --debug  <mode>      Debug mode (default = NONE)

  -r, --fileInteractive    File interactive mode

  -f, --files  <file>...   Input file list

  -i, --interactive        Interactive mode

  -o, --output  <file>     Redirect program output to a file

  -p, --process            Force smt process usage

  -v, --shortVersion       Version number

  -s, --stdin              Read from standard input

  -t, --test               Test mode

      --help               Show help message

      --version            Show version of this program
```

Notes
-----

For option `-f, --files`, if `<file>` is a directory all files with extension
`.fsp` in the directory `<file>` are executed

By default if you don't provide arguments the program will execute in interactive mode

A FunSpec program is composed by a sequence (possibly empty) of type definitions,
predicate definitions or implications/equivalences between assertions

Quick Example
=============

```
x:int

x >= 0 ==> x + 1 > 0

;;
```